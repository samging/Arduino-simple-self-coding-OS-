const int an_0 = A0;
const int an_1 = A1;
const int an_2 = A2;
const int an_3 = A3;
const int an_4 = A4;
const int an_5 = A5;

double active_listener[6] = {0, 0, 0, 0, 0, 0};  // Tracks active time for each analog pin

const int dig_0 = 0;
const int dig_1 = 1;
const int dig_2 = 2;
const int dig_3 = 3;
const int dig_4 = 4;
const int dig_5 = 5;
const int dig_6 = 6;
const int dig_7 = 7;
const int dig_8 = 8;
const int dig_9 = 9;
const int dig_10 = 10;
const int dig_11 = 11;
const int dig_12 = 12;
const int dig_13 = 13;

// Global memory to store concatenated lists across iterations
int memorized_concated_list[20] = {0};

// Make these persistent across iterations
unsigned int persistent_analog_memory[6] = {0, 0, 0, 0, 0, 0};
unsigned int persistent_digital_memory[14] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

void setup() {
  Serial.begin(9600);

  // Initialize analog pins as INPUT_PULLUP (if being used digitally)
  pinMode(an_0, INPUT_PULLUP);
  pinMode(an_1, INPUT_PULLUP);
  pinMode(an_2, INPUT_PULLUP);
  pinMode(an_3, INPUT_PULLUP);
  pinMode(an_4, INPUT_PULLUP);
  pinMode(an_5, INPUT_PULLUP);  

  pinMode(dig_0, INPUT_PULLUP);
  pinMode(dig_1, INPUT_PULLUP);
  pinMode(dig_2, INPUT_PULLUP);
  pinMode(dig_3, INPUT_PULLUP);
  pinMode(dig_4, INPUT_PULLUP);
  pinMode(dig_5, INPUT_PULLUP);
  pinMode(dig_6, INPUT_PULLUP);
  pinMode(dig_7, INPUT_PULLUP);
  pinMode(dig_8, INPUT_PULLUP);
  pinMode(dig_9, INPUT_PULLUP);
  pinMode(dig_10, INPUT_PULLUP);
  pinMode(dig_11, INPUT_PULLUP);
  pinMode(dig_12, INPUT_PULLUP);
  pinMode(dig_13, INPUT_PULLUP);
}

void listener_DIGITAL(unsigned int* temp_digital_memory) {
  int digital_pins[14] = {dig_0, dig_1, dig_2, dig_3, dig_4, dig_5, dig_6, dig_7, dig_8, dig_9, dig_10, dig_11, dig_12, dig_13};

  for (int i = 0; i < 14; i++) {
    int digital_status = digitalRead(digital_pins[i]);

    if (digital_status == LOW) {
      Serial.print("ACTIVE_DIG - pin ");
      Serial.println(i);
      if (temp_digital_memory[i] <= 0) {
        temp_digital_memory[i] += 1;
      }
    }
  }
}

void listener_ANALOG(unsigned int* temp_analog_memory) {
  int analog_pins[6] = {an_0, an_1, an_2, an_3, an_4, an_5};

  for (int i = 0; i < 6; i++) {
    int state = digitalRead(analog_pins[i]);

    if (state == LOW) {
      Serial.print("ACTIVE_AN - pin: ");
      Serial.println(i);
      if (temp_analog_memory[i] <= 0) {
        temp_analog_memory[i] += 1;
      }
    }
  }
}

// Function to store and update the memorized concated list
void update_memory(int* concated_list) {
  Serial.println("Updating memory...");
  
  for (int i = 0; i < 20; i++) {
    memorized_concated_list[i] = concated_list[i];  // Update the global memory
  }

  // Print memorized list for debugging
  Serial.print("Memorized List: ");
  for (int i = 0; i < 20; i++) {
    Serial.print(memorized_concated_list[i]);
    Serial.print(" ");
  }
  Serial.println();
}

void position_conv(unsigned int* temp_analog_memory, unsigned int* temp_digital_memory) {
  int concated_list[20];  // To hold combined analog and digital memory

  // Concatenate both arrays (analog and digital)
  for (int i = 0; i < 6; i++) {
    concated_list[i] = temp_analog_memory[i];
  }
  for (int i = 0; i < 14; i++) {
    concated_list[i + 6] = temp_digital_memory[i];
  }

  Serial.print("Concated List: ");
  for (int i = 0; i < 20; i++) {
    Serial.print(concated_list[i]);
    Serial.print(" ");
  }
  Serial.println();

  // Update memory with the new concatenated list
  update_memory(concated_list);
}
void getPositions(int concated_list[20]){
  // Positions process list
  for(int position_index = 0; position_index < 20; position_index++){
    // Create the formatted string
    int positions_process = string(concated_list[position_index]) +string(":")+ string(position_index);
    
    // Print the result
    Serial.print(positions_process);
  }
  for(int input_positions=0; input_position < 6; input_position++){ //just slicing first 6 numbers
    
    int slice_1_1_list{6} = {0,0,0,0,0,0};
    int slice_1_2_list{6} = {0,0,0,0,0,0};
    int slice_1_1[input_postitions] = positions_process.slice(":")[1]; //loops 6 positions and slices into vairable
    slice_1_1_list[input_position] += slice_1_1; //adding into list_1_1
    int slice_1_2 = positions_process.slice(":")[2];//the same should happend here (but takes the second element 'after' the `:`)
    slice_1_2_list[input_position] += slice_1_2;
    //In the summary the "task-manager" will know by slice_1_1_list state of pin (active or not), slice_1_2_list (number of pin)
    //Expected to work with slice vectors.
  }
  for(int output_positions=6; output_positions<20; output_positions;){
    int slice_2_1_list[14] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    int slice_2_2_list[14] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    int slice_2_1[output_postitions] = positions_process.slice(":")[1]; //loops 14 positions and slices into vairable
    slice_2_1_list[output_position] += slice_2_1; //adding into list_2_1
    int slice_2_2[output_postitions] = positions_process.slice(":")[1]; //loops 14 positions and slices into vairable
    slice_2_2_list[output_position] += slice_2_2; //adding into list_2_1
  } //knowing the states of input pins (slice_2_1_list = device state, slice_2_2_list = device port);
}

void Process_S(int input_state, int input_port, int output_state, int output_port, bool stop, bool pause){
  int list_of_actives_IN[...]={}; int list_of_actives_OUT[...]={};
  int names_PID[1000] = {};
  for(process_index=0;process_index<21;process_index++){if(input_state[process_index] == 1){while(output_state[process_index] == 1){if(input_state[process_index]==1){
    int active_in_{0+process_index}); list_of_actives_IN+=active_in_{0+process_index}}}//should obtain active_in processes in context of active_in as active inputs.
  if(output_state[process_index] == 1){int active_out_{0+process_index}) list_of_actives_OUT+=active_out_{0+process_index} for(PID=0; PID<1000; PID++){ names_PID += int process_variable[PID] = active_in, active_out;}task_manager(process_variable);}}
  for(int PID_limit = 0; PID_limit < 1000; process_varialbe[PID_limit++]){if(active_in == HIGH){digitalWriteline(active_out); time.sleep(10000);Serial.println("PROCESS: "+"IN:"+active_in+"OUT:"+active_out);}}
}
//retrive task, list_of_actives_IN - (1,2,3,4,5,3,2,4,5,1) == list_of_actives_OUT - (6,7,9,12,9,11,10,9,8,10)
void taks_looper(){
  
}
void task_manager(int active_in_list_memory_stop, int active_out_list_memory_stop, int active_in_memory_pause, int active_out_memory_pause, int active_in_list_memory_stop, int active_out_list_memory_stop, int names_PID,
  int updated_pause_states_in, int updated_pause_states_out, int int bool updated_pause_states, int updated_pause_states_state){
  for(PID=0; PID << 1000; PID++){
  default bool stop[PID] = false;
  default bool pause[PID] = false;
  default bool req_unpause[PID] == false;
  default bool req_unfreeze[PID] == false; 
  }
  string user_input = input(string("Type: PID/STOP>>\n"));
  Serial.println("------------");
  if(user_input == "PID"){
    int PID_ID = input(int("Request of your's PID_ID:>>"));
  }else if(user_input == "STOP"){
    int STOP_ID = input(int("Request of your's STOP_ID:>>"));
  }else{
    bool need_update = false;
    char unfreeze = input("Resume Process?(Y/N)>>");if(unfreeze=="Y"){string pid_to_unfreeze = input(int("Enter number of PID: ")); RESUME_UNFREEZE_MEMORY[PID]+=pid_to_unfreeze;}
    else if(unfreeze=="N"){Serial.println("Processes are active: ");Serial.println(process_variable[PID]); need_update=true;}else{Serial.println("---Nothing was disrupted (process - task_manager)---");}
  }

  int STOP_MEMORY[...] = {};
  int PAUSE_ID_MEMORY[...] = {};
  int RESUME_UNFREEZE_MEMORY[...] = {}; //representation of all values inside should look like PID towards others ID's/PID processes.
  if(need_update == true){
    for(TTL__LIST = 0; TTL__LIST < 1000; TTL__LIST++){
        STOP_MEMORY[TTL_LIST] += STOP_ID;
        PAUSE_ID_MEMORY[TTL__LIST] += PID_ID
      }
      Serial.println("Updated process status");
      Serial.println(process_variable[PID]);
    }
  } //Writing states from processes. 
  stop_memory_action(STOP_MEMORY);
  pause_memory_action(PAUSE_ID_MEMORY);
  resume_memory_action(RESUME_UNFREEZE_MEMORY);
  int unfreeze_process[1000]={}; int unstop_process[sizeOf(unfreeze_process)]={};
  
  const bool unpause=ture; const bool unstop=true;
  for(indexation=0; indexation<1000;indexation++){if(STOP_MEMORY!=NULL){})} //let `Process_S` inform about any PID's changes 
}

void stop_memory_action(int memory_statuses, int active_in_list, int active_out_list){ //input are memory states, that are configured while code execution.
  int action_memmory_locations[1000] = {...};//get all '...'
  for(memory_statuses_location=0; memory_statuses_location<1000; memory_statuses_location++){
    if(memory_statuses[memory_statuses_location]!=NULL){
      action_memmory_locations+=memory_statuses[memory_statuses_location];
      if(action_memmory_locations[memory_statuses_location] == NULL || 0) {slice.action_memmory_locations[memory_statuses_location]} //removes zeros from list
    } // {1,6,7,8,9,...} - all non NULL are processes that waits/remaining for stopping cycle
    for(memory_destinaitons=0; memory_destinaitons<sizeOf(action_memmory_locations); memory_destinaitons++){ //looping for as many memory_statuses
    int PID_STOP_AC[...]= action_memmory_locations[memory_destinaitons]; //list_of_actives_IN - (1,2,3,4,5,3,2,4,5,1) == list_of_actives_OUT - (6,7,9,12,9,11,10,9,8,10)
    for each(PID_PAUSE_AC=PID_PAUSE_AC[0];PID_PAUSE_AC<sizeOf(pause_memmory_locations); PID_PAUSE_AC[sizeOf(pause_memmory_locations+1)]){  
    active_out_list[PID_STOP_AC] = 0;
    active_in_list[PID_STOP_AC] = 0;
    int active_in_list_memory_stop[...] = {};
    int active_out_list_memory_stop[...] = {};  
    task_manager(active_in_list_memory_stop, active_out_list_memory_stop); //TASK-MANAGER values (REPLACE!).
    } //instead of jumping one plus he should just jump in position and retrieve the value to lopp init.

    }

  }
}


//====UNDONE====
void pause_memory_action(int pause_memory_statuses, int active_in_list, int active_out_list, int PAUSE_ID_MEMORY){ //input are memory states, that are configured while code execution.
  const bool default_state = false;
  const bool set_pause = true;
  int, int, bool updated_pause_states[...] = {};
  int updated_pause_states_in[...] = {}; //undefined size
  int updated_pause_states_out[sizeOf(updated_pause_states_in)] = {};
  int updated_pause_states_state[sizeOf(updated_pause_states_in)] = {};
  int pause_memmory_locations[1000] = {...};//get all '...'
  for(pause_statuses_location=0; pause_statuses_location<1000; pause_statuses_location++){
    if(pause_memory_statuses[pause_statuses_location]!=NULL){
      pause_memmory_locations+=memory_statuses[pause_statuses_location];
      if(pause_memmory_locations[pause_statuses_location] == NULL || 0) {slice.pause_memmory_locations[pause_statuses_location]} //removes zeros from list
    for(pause_memo_start=int(puser_memory_locations[0]); pause_memor_start <= sizeOf(pause_memmory_locations); pause_memo_start){
      int memory_assigned_pauses += for(every_pause=0; every_pause<sizeOf(pause_memory_locations); every_pause++){pause_memmory_locations[every_pause]} //retrieving statues and pause-statuses
      for(memory_assigned_pauses=[0,0]; memory_assigned_pauses <= sizeOf(pause_memory_locations)*2; memory_assigned_pauses++)int, bool memory_assigned_pauses[assign_status_of_pause] = memory_assigned_pauses[sizeOf(memory_assigned_pauses)] += default_state; // should Issue state for each pause_memory_locations as false
    } //output is {{1,false},{2,false},{n,false}}
    } 
    for(pause_memory_destinaitons=0; pause_memory_destinaitons<sizeOf(pause_memmory_locations); pause_memory_destinaitons++){ //looping for as many memory_statuses
    int PID_PAUSE_AC[...]= pause_memmory_locations[pause_memory_destinaitons]; //list_of_actives_IN - (1,2,3,4,5,3,2,4,5,1) == list_of_actives_OUT - (6,7,9,12,9,11,10,9,8,10)
    for(enumerate_pause_processes=PAUSE_ID_MEMORY[0]; enumerate_pause_processes < sizeOf(PAUSE_ID_MEMORY); enumerate_pause_processes++){
      if(PAUSE_ID_MEMORY[enumerate_pause_processes] == true){
        memory_assigned_pauses[enumerate_pause_processes][2] = default_state; //inside is something like this{1,4,false} 
        updated_pause_states_in[enumerate_pause_processes] += memory_assigned_pauses[enumerate_pause_processes][0]; //(1) == picked .0.0
        updated_pause_states_out[enumerate_pause_processes] += memory_assigned_pauses[enumerate_pause_processes][1]; //1.(0) == picked.0
        updated_pause_states_state[enumerate_pause_processes] += memory_assigned_pauses[enumerate_pause_processes][2];//1.0.(0) == picked
      }updated_pause_states[...] += memory_assigned_pauses //in end of processes we get upadated statuses {{3},{8},{false}}
      if(sizeOf(updated_pause_states_in)!=sizeOf(updated_pause_states_out)&sizeOf(updated_pause_states_state)!=sizeOf(updated_pause_states_in)){
        break;
      }
    }
    task_manager(updated_pause_states_in, updated_pause_states_out, updated_pause_states, updated_pause_states_state); //TASK-MANAGER values (REPLACE!).
    resume_memory_action(updated_pause_states_in, updated_pause_states_out, updated_pause_states, updated_pause_states_state);

    } //instead of jumping one plus he should just jump in position and retrieve the value to lopp init.

    }

  }
}
//====UNDONE++====
void resume_memory_action(int updated_pause_states_in, int updated_pause_states_out, int RESUME_UNFREEZE_MEMORY, bool updated_pause_states_state){ //input are memory states, that are configured while code execution.
  const bool default_state = false; //{{1}{8}{true}}
  const bool set_pause = true;
  int map_of_processes_resume_AC[sizeOf(RESUME_UNFREEZE_MEMORY)] = {};
  int, int, bool updated_pause_states[...] = {};
  int updated_pause_states_in[...] = {}; //undefined size
  int updated_pause_states_out[sizeOf(updated_pause_states_in)] = {};
  int updated_pause_states_state[sizeOf(updated_pause_states_in)] = {};
  int pause_memmory_locations[1000] = {...};//get all '...'
  for(resume_positions_looper=0; resume_positions_looper < sizeOf(updated_pause_states_state); resume_positions_looper++){
    if(updated_pause_states_state[resume_positions_looper]==true){ //3 = PID{3, 5,10,}
      while(resume_positions_looper<sizeOf(updated_pause_states_state)){
      map_of_processes_resume_AC += resume_positions_looper;
      } for()
      updated_pause_states_state[resume_positions_looper]=false;
      //Process identifier? == position from the arrray;
        //example: "Pause process Y/N>>" Y; "Enter PID>>" 3 - RESUME_UNFREEZE_MEMORY:(3,5,6,9);
          //resume_positions_looper = update_pause_state_state[user_input_pid];
           //update_pause_state_state[resume_positions_looper] = true;

    }
  }
  for(pause_statuses_location=0; pause_statuses_location<1000; pause_statuses_location++){
    if(pause_memory_statuses[pause_statuses_location]!=NULL){
      pause_memmory_locations+=memory_statuses[pause_statuses_location];
      if(pause_memmory_locations[pause_statuses_location] == NULL || 0) {slice.pause_memmory_locations[pause_statuses_location]} //removes zeros from list
    for(pause_memo_start=int(puser_memory_locations[0]); pause_memor_start <= sizeOf(pause_memmory_locations); pause_memo_start){
      int memory_assigned_pauses += for(every_pause=0; every_pause<sizeOf(pause_memory_locations); every_pause++){pause_memmory_locations[every_pause]} //retrieving statues and pause-statuses
      for(memory_assigned_pauses=[0,0]; memory_assigned_pauses <= sizeOf(pause_memory_locations)*2; memory_assigned_pauses++)int, bool memory_assigned_pauses[assign_status_of_pause] = memory_assigned_pauses[sizeOf(memory_assigned_pauses)] += default_state; // should Issue state for each pause_memory_locations as false
    } //output is {{1,false},{2,false},{n,false}}
    } 
    for(pause_memory_destinaitons=0; pause_memory_destinaitons<sizeOf(pause_memmory_locations); pause_memory_destinaitons++){ //looping for as many memory_statuses
    int PID_PAUSE_AC[...]= pause_memmory_locations[pause_memory_destinaitons]; //list_of_actives_IN - (1,2,3,4,5,3,2,4,5,1) == list_of_actives_OUT - (6,7,9,12,9,11,10,9,8,10)
    for(enumerate_pause_processes=PAUSE_ID_MEMORY[0]; enumerate_pause_processes < sizeOf(PAUSE_ID_MEMORY); enumerate_pause_processes++){
      if(PAUSE_ID_MEMORY[enumerate_pause_processes] == true){
        memory_assigned_pauses[enumerate_pause_processes][2] = default_state; //inside is something like this{1,4,false} 
        updated_pause_states_in[enumerate_pause_processes] += memory_assigned_pauses[enumerate_pause_processes][0]; //(1) == picked .0.0
        updated_pause_states_out[enumerate_pause_processes] += memory_assigned_pauses[enumerate_pause_processes][1]; //1.(0) == picked.0
        updated_pause_states_state[enumerate_pause_processes] += memory_assigned_pauses[enumerate_pause_processes][2];//1.0.(0) == picked
      }updated_pause_states[...] += memory_assigned_pauses //in end of processes we get upadated statuses {{3},{8},{false}}
      if(sizeOf(updated_pause_states_in)!=sizeOf(updated_pause_states_out)&sizeOf(updated_pause_states_state)!=sizeOf(updated_pause_states_in)){
        break;
      }
    }
    task_manager(updated_pause_states_in, updated_pause_states_out, updated_pause_states, updated_pause_states_state); //TASK-MANAGER values (REPLACE!).
    resume_memory_action(updated_pause_states_in, updated_pause_states_out, updated_pause_states, updated_pause_states_state);

    } //instead of jumping one plus he should just jump in position and retrieve the value to lopp init.

    }

  }
}
void loop() {
  listener_ANALOG(persistent_analog_memory);
  listener_DIGITAL(persistent_digital_memory);

  position_conv(persistent_analog_memory, persistent_digital_memory);

  delay(1000); // Wait before the next iteration
}

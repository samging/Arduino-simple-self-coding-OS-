import os
import tkinter as tk
from tkinter import messagebox, PhotoImage, Toplevel, Listbox, Scrollbar
from pathlib import Path
import random
from tkinter import ttk
def show_file_details(event):
    selected_file = file_listbox.get(file_listbox.curselection())
    file_path = os.path.join(downloads_dir, selected_file)
 
    # Create a new window to show file details
    fileexplorer_window = Toplevel(root)
    fileexplorer_window.geometry("500x400")
    fileexplorer_window.title("File Details")
 
    frame = tk.Frame(fileexplorer_window)
    frame.pack(expand=True, padx=20, pady=20)
 
    if os.path.isfile(file_path):
        file_size = os.path.getsize(file_path)
        messagebox.showinfo("File Details", f"File: {selected_file}\nSize: {file_size} bytes")
    else:
        messagebox.showinfo("Directory", f"{selected_file} is a folder")
 
def populate_file_list():
    files = os.listdir(downloads_dir)
    for file in files:
        file_listbox.insert(tk.END, file)
 
def open_file_explorer():
    # Create a new window for the file explorer
    fileexplorer_window = Toplevel(root)
    fileexplorer_window.geometry("500x400")
    fileexplorer_window.title("File Explorer")
 
    frame = tk.Frame(fileexplorer_window)
    frame.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)
 
    # Create a scrollbar for the file list
    scrollbar = Scrollbar(frame)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
 
    # Create a Listbox to display the files
    global file_listbox
    file_listbox = Listbox(frame, yscrollcommand=scrollbar.set, font=("Arial", 12), selectmode=tk.SINGLE)
    file_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
 
    # Configure the scrollbar
    scrollbar.config(command=file_listbox.yview)
 
    # Bind the event when the user clicks a file
    file_listbox.bind('<<ListboxSelect>>', show_file_details)
 
    # Populate the Listbox with files from the Downloads directory
    populate_file_list()
 
# Get the Downloads directory path
downloads_dir = str(Path.home() / "Downloads")


dummy_ram_usage = random.randint(1,100)
dummy_cpu_usage = random.randint(1,100)
dummy_network_usage = random.randint(1,100)
dummy_PID = ["0001","0002","0003"]
dummy_tasks_in = ["A1", "A3", "A5"]
dummy_tasks_out = ["7", "9", "13"]
dummy_paused_tasks = ["0004"] 
def open_task_manager(dummy_PID, dummy_paused_tasks, dummy_tasks_out, dummy_tasks_in, dummy_ram_usage, dummy_cpu_usage, dummy_network_usage):
    # Create a new window for the file manager
    file_manager_window = Toplevel(root)
    file_manager_window.geometry("400x400")
    file_manager_window.title("File Manager")
 
    # Create a frame for the layout
    main_frame = tk.Frame(file_manager_window)
    main_frame.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)
 
    # Create the top grid frame
    top_frame = tk.Frame(main_frame)
    top_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
 
    # Create the bottom grid frame
    bottom_frame = tk.Frame(main_frame)
    bottom_frame.pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True)
 
    # Create and pack the usage statistics header
    header = tk.Label(top_frame, text="System Usage", font=("Arial", 14, "bold"))
    header.pack(pady=5)
 
    # Create usage statistics (CPU, RAM, Network)
    stats_frame = tk.Frame(top_frame)
    stats_frame.pack()
 
    ram_label = tk.Label(stats_frame, text=f"RAM Usage: {dummy_ram_usage}%")
    ram_label.grid(row=0, column=0, padx=10, pady=5)
 
    cpu_label = tk.Label(stats_frame, text=f"CPU Usage: {dummy_cpu_usage}%")
    cpu_label.grid(row=0, column=1, padx=10, pady=5)
 
    network_label = tk.Label(stats_frame, text=f"Network Usage: {dummy_network_usage}%")
    network_label.grid(row=0, column=2, padx=10, pady=5)
 
    # Create PID details table
    pid_header = tk.Label(top_frame, text="PID Details", font=("Arial", 12, "bold"))
    pid_header.pack(pady=5)
 
    pid_tree = ttk.Treeview(top_frame, columns=("PID", "CPU", "RAM", "Network"), show="headings")
    pid_tree.heading("PID", text="PID")
    pid_tree.heading("CPU", text="CPU Usage")
    pid_tree.heading("RAM", text="RAM Usage")
    pid_tree.heading("Network", text="Network Usage")
 
    pid_tree.pack(expand=True, fill=tk.BOTH)
 
    # Insert dummy PID details
    for pid in dummy_PID:
        pid_tree.insert("", "end", values=(pid, f"{random.randint(0,100)}%", f"{random.randint(0,100)}%", f"{random.randint(0,100)}%"))
 
    # Create the paused tasks section
    paused_tasks_header = tk.Label(bottom_frame, text="Paused Tasks", font=("Arial", 12, "bold"))
    paused_tasks_header.pack(pady=5)
 
    paused_tasks_list = tk.Listbox(bottom_frame, height=5)
    paused_tasks_list.pack(expand=True, fill=tk.BOTH)
 
    # Insert dummy paused tasks
    for task in dummy_paused_tasks:
        paused_tasks_list.insert(tk.END, f"PID: {task} - CPU: 0% - RAM: 0% - Network: 0%")

 
root = tk.Tk()
root.title("Main Window")
root.geometry("640x640")
root.config(bg="#1E90FF")

# Example dummy data
dummy_PID = ["0001", "0002", "0003"]
dummy_paused_tasks = ["0004"]
dummy_tasks_in = ["A1", "A3", "A5"]
dummy_tasks_out = ["7", "9", "13"]
dummy_ram_usage = random.randint(1, 100)
dummy_cpu_usage = random.randint(1, 100)
dummy_network_usage = random.randint(1, 100)

# Call the function to test it
open_task_manager(dummy_PID, dummy_paused_tasks, dummy_tasks_out, dummy_tasks_in, dummy_ram_usage, dummy_cpu_usage, dummy_network_usage)
 
# Load an icon for the button
app1_icon = PhotoImage(file="filexpsmall.png")  # Make sure this path is correct
task_m_icon = PhotoImage(file="taskmanager_small.png")
task_button = tk.Button(root, image=task_m_icon, command=open_task_manager, bd=0)
task_button.place(x=10, y=60)

# Create a button with the icon and link it to the open_file_explorer function
icon_button = tk.Button(root, image=app1_icon, command=open_file_explorer, bd=0)
icon_button.place(x=10, y=10)  # Position the button at the upper-left corner
 
# Create a label for text in the bottom-right corner
bottom_right_label = tk.Label(root, text="Arduino OS", font=("Arial", 20), fg="black", bg="#1E90FF")
bottom_right_label.pack(side=tk.BOTTOM, anchor=tk.SE, padx=70, pady=30)
 
# Run the Tkinter event loop
root.mainloop()